float cauchy(float x);
float gumbel(float x, float mi, float beta);
float laplace(float x, float mi, float beta);